function EnableBlackScreen()
  {
  	//alert("ok");
    document.getElementById("BlackScreen").style.display="block";
  }

function DesableBlackScreen()
    {
        document.getElementById("BlackScreen").style.display="none";
    }