function newCategorie()
{
	//alert("ok");
	document.getElementById("AddCategorie").style.display="block";
	//el.style.display = 'block';
}
function CatCancel()
{
	document.getElementById("AddCategorie").style.display="none";
}