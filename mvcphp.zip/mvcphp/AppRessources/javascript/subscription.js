function inscriptpart() 
{
    document.getElementById("inspar").style.display="block";
    document.getElementById("inscom").style.display="none";
    document.getElementById("titpar").style.display="block";
    document.getElementById("titbout").style.display="none";
    document.getElementById("navinspar").style.backgroundColor="#17a8f2";
    document.getElementById("navinscom").style.backgroundColor="lightgrey";
}

function inscriptcom() {
   document.getElementById("inspar").style.display="none";
   document.getElementById("inscom").style.display="block";
   document.getElementById("titbout").style.display="block";
   document.getElementById("titpar").style.display="none";
   document.getElementById("navinspar").style.backgroundColor="lightgrey";
   document.getElementById("navinscom").style.backgroundColor="#17a8f2";
}

function adresse(element)
{
    var idx=element.selectedIndex;
    var pays=element.options[idx].innerHTML;  
    if ((pays=='France')) 
      {
        document.getElementById('Cadressecomores').style.display='none';
        document.getElementById('Cadressefrance').style.display='block';        
      }
    else 
      {
        if((pays=='Comores'))
          {
          document.getElementById('Cadressecomores').style.display='block';
          document.getElementById('Cadressefrance').style.display='none';
          }
      }       
}