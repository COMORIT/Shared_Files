function Modify(element)
  {
  	console.log(element.id);
  	if (element.id=="Intro") {
    document.getElementById("IntroductionSection").style.display="block";
     }
    if (element.id=="Adresse") {
    document.getElementById("AdresseSection").style.display="block";
     }
    if (element.id=="Phone") {
    document.getElementById("PhoneSection").style.display="block";
     }
    if (element.id=="Horaires") {
    document.getElementById("HorairesSection").style.display="block";
     }
    if (element.id=="Admin") {
    document.getElementById("AdminSection").style.display="block";
     }
  }

function ModifyCancel()
  {
  var elements = document.getElementsByClassName("ModifFrame");
  for (var i =elements.length - 1; i >= 0; i--) {
  elements[i].style.display="none";
  }
  //elements.forEach(element=>element.style.display= "none");	
  }

function AddItem()
{}