function newCategorie()
{
	//alert("ok");
	document.getElementById("AddCategorie").style.display="block";
	//el.style.display = 'block';
}
function CatCancel()
{
	document.getElementById("AddCategorie").style.display="none";
	document.getElementById("AddItem").style.display="none";
}
function newItem()
{
	//alert("ok");
	document.getElementById("AddItem").style.display="block";
	//el.style.display = 'block';
}