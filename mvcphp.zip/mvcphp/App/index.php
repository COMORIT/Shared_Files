<?php  
/*
function __autoload($class_name)
{
	require_once ''
}
*/
require_once('./Routes/Routes.php');
?>