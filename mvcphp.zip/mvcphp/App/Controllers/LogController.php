<?php
/**
 * 
 */
class LogController extends Controller implements InterfaceController
{
	public static function index($param=array())
	{
		self::ShopLogIn($_POST['email'],$_POST['password']);
		parent::view('test/index.php',["title"=>'home',"logResult"=>'boolen']);
	}

	private static function ShopLogIn($email,$motdepasse)
	{
        session_start();
		if(empty($email) || empty($motdepasse))
			{  
   				header('Location: http://localhost/mvcphp/App/subscription/email');
   				exit(); 
			}
		else{
				$dBname = 'djamnazi_marchands';
   				$db = new Database($dBname);
  				$found = $db->SearchIn(array('Motdepasse','Objet'),'pds',array('Email' => $email));
  				var_dump($found);
   				if(empty($found))
   				{
   				   header('Location: http://localhost/mvcphp/App/subscription/registration');
   				   exit();      
   				}
   				else
   				{
   				 	if(password_verify($_POST['motdepasse'],$found[0]['motdepasse']))
   				  	{
   				  	   session_regenerate_id();
   				  	   $_SESSION['Objet'] = unserialize($found[0]['Objet']);
   				  	   if($_SESSION['Objet']->statut!='Particulier') 
   				  	   {
   				  	      $_SESSION['maboutique'] = unserialize($found[0]['Objet']);
   				  	   }     
  	                   header('Location: Location: http://localhost/mvcphp/App/home/');
   				       exit();  
   				  	}
     				else 
    				{
    	 				$found = NULL;
    	 				header('Location: ../pages/inscription.php?souci=wpass');
       					exit();  
    				}
    			}
    		}
	}

	public function LogOut()
	{} 
}

  ?>