<?php
require_once("Controller.php");  
require_once("./Modeles/Shop.php"); 
require_once("./Modeles/Admin.php"); 
require_once("./Modeles/Database.php");
class BazarController extends Controller implements InterfaceController
{
	public static function index($param=array())
	{
		//parent::view('bazar/index.php',["title"=>'Bazar']);
		parent::SetTwig();
		parent::SessionStart();

        $success = 0;

		if(isset($_POST['Shop']))
		 {  
		 	echo parent::$twig->render('bazar.twig', ['title' => 'Bazar',"LogIn"=>"Identification","Shop"=>$_POST["Shop"]]);
		 }
		elseif(isset($param[1])&&$param[1]=="update")
		{
            self::UpdateInfo();
           $Shop = $_SESSION["MyOwnShop"];
           //$Shop->setNom(ucfirst($Shop->getNom()));
           //var_dump($Shop);
           echo parent::$twig->render('bazar.twig', ['title' => 'Bazar',"LogIn"=>"Ma Boutique","MyCount"=>$_SESSION["MyOwnShop"],"Shop"=>$Shop]);
           //var_dump($param);
		}
		elseif(isset($_SESSION["MyOwnShop"]))
		{
           $Shop = $_SESSION["MyOwnShop"];
           //  var_dump($_SESSION);
           $Shop->setNom(ucfirst($Shop->getNom())); 
           echo parent::$twig->render('bazar.twig', ['title' => 'Bazar',"LogIn"=>"Ma Boutique","MyCount"=>$_SESSION["MyOwnShop"],"Shop"=>$Shop]);
		}
		else
		 { 
		 	//echo parent::$twig->render('home.twig', ['title' => 'home',"LogIn"=>"Identification"]);
		 }
	}

	public static function UpdateInfo()
	{
		$res =0;
		if(isset($_POST["nom"]))
		{
				$_SESSION["MyOwnShop"]->setNom($_POST["nom"]);
				$s = serialize($_SESSION['MyOwnShop']);
				$db = new Database();
				$res = $db->updateValue(array('Nom'=>$_POST["nom"],'Objet'=>$s),"pds",array('Email' => $_SESSION["MyOwnShop"]->getEmail()));
		}
	    if(isset($_POST["description"]))
		{
				$_SESSION["MyOwnShop"]->presentation=$_POST["description"];
				$s = serialize($_SESSION['MyOwnShop']);
				$db = new Database();
				$res = $db->updateValue(array('Objet'=>$s),"pds",array('Email' => $_SESSION["MyOwnShop"]->getEmail()));
		}
		
	    if(isset($_POST["ville"])&&isset($_POST["region"]))
		{
				$_SESSION["MyOwnShop"]->updateAdresse($_POST["ville"]." ".$_POST["region"]);
				$s = serialize($_SESSION['MyOwnShop']);
				$db = new Database();
				$res = $db->updateValue(array('Ville'=>$_POST["ville"],'Objet'=>$s),"pds",array('Email' => $_SESSION["MyOwnShop"]->getEmail()));
		}
	    if(isset($_POST["phone"]))
		{
				$_SESSION["MyOwnShop"]->setTelephone($_POST["phone"]);
				$s = serialize($_SESSION['MyOwnShop']);
				$db = new Database();
				$res = $db->updateValue(array('Objet'=>$s),"pds",array('Email' => $_SESSION["MyOwnShop"]->getEmail()));
		}
		if(isset($_POST["hours"]))
		{
			self::UpdateHours($_POST);
		}
	    if(isset($_POST["admin"]))
		{
			//self::UpdateAdmin($_POST);
			$_SESSION["MyOwnShop"]->setAdmin($_POST);
			$s = serialize($_SESSION['MyOwnShop']);
			$db = new Database();
			$res = $db->updateValue(array('Objet'=>$s),"pds",array('Email' => $_SESSION["MyOwnShop"]->getEmail()));
		}
		
        return $res;
	}

	public static function UpdateHours($form)
	{
		$day = array();
		$horaires = array();
		foreach ($form as $key => $value) {
			if(isset(explode("_", $key)[1]))
				{
					$day = array(explode("_", $key)[0],explode("_",$key)[1]);
					if(isset($_SESSION["MyOwnShop"]->horaires[$day[0]])&&!isset($horaires[$day[0]]))
					{
						$horaires[$day[0]]=array();
					}
					if(isset($_SESSION["MyOwnShop"]->horaires[$day[0]])&&$day[1]=="o")
					{
                       $horaires[$day[0]][0]=$value."h";
					}
					elseif(isset($_SESSION["MyOwnShop"]->horaires[$day[0]])&&$day[1]=="f")
					{
                       $horaires[$day[0]][1]=$value."h";
					}
				}
		}
		if(!empty($horaires))
		{
			$_SESSION["MyOwnShop"]->horaires = $horaires;
			$s = serialize($_SESSION['MyOwnShop']);
			$db = new Database();
			$res = $db->updateValue(array('Objet'=>$s),"pds",array('Email' => $_SESSION["MyOwnShop"]->getEmail()));
		}
		var_dump($horaires);
		var_dump($res);
	}
	public static function UpdateAdmin($form)
	{
        //var_dump($form);
        
	}   
}
?>