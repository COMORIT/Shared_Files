<?php 
interface InterfaceController
{
	public static function index($param=array());
}
?>