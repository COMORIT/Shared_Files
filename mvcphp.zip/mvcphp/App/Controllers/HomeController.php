<?php
require_once("Controller.php");
require_once("./Modeles/Categorie.php");  
require_once("./Modeles/Shop.php");
require_once("./Modeles/Database.php"); 
class HomeController extends Controller implements InterfaceController
{
	public static function index($param=array())
	{
		//parent::view('home/index.php',["title"=>'Home']);
	    parent::SessionStart();
		parent::SetTwig();
        if(isset($param[1])&&$param[1]=="logout")
        {
        	session_unset();
        }
      	if(!isset($_POST['httpArgs'][1])||empty($_POST['httpArgs'][1]))
		{
			$parent = "root";
		}
		else
		{
			$parent = $_POST['httpArgs'][1];
		}
		$_POST['httpArgs'] = "";
		if(isset($_POST['categorie'])&&($_POST['categorie']=="yes"))
		{
            self::newCategorie();
		}
		$p = Categorie::getCategorie($parent);
		$k = Categorie::getCategories($parent);
		if(empty($k))
		{
		  $p = Categorie::getCategorie("root");
		  $k = Categorie::getCategories("root");
		} 
		if(isset($_SESSION["MyOwnShop"]))
		{
			echo parent::$twig->render('myitems.twig', ['title' => 'cheha',"LogIn"=>"Ma Boutique", "MyCount"=>$_SESSION["MyOwnShop"],'categories'=>$k,'parent'=>$p]);
	    }
	    else
	    {
	    	echo parent::$twig->render('home.twig', ['title' => 'cheha',"LogIn"=>"Identification", 'parent'=>$p,'categories'=>$k]);
	    }

	}
    
    private static function newCategorie()
    {
    	    if($_POST['ParentCategorie']=="")
    	    	{$parent="root";}
    	    else{$parent = $_POST['ParentCategorie'];}
    	   $newCat = new Categorie($_POST['NomCategorie'],$parent);
           foreach ($_POST as $key => $value) 
           {
             if((strpos($key,"Filtre")===0)&&($value != "")&&(strpos($key,"Options")===False))
             {
             	$op = explode(',', $_POST[$key."Options"]);
             	$newCat->addFiltre($value,$op);
             }	 
           }
           $SerNewCat = serialize($newCat);
           $newCat->saveCategorie($SerNewCat);   
    } 
}
?>