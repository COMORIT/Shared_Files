<?php 
require_once 'InterfaceController.php';
require_once('./../vendor/autoload.php');  
class Controller
{
   public static $loader = null;
   public static $twig = null;
   public static function SetTwig()
   {
      $templates = dirname(__DIR__).'/templates';
      $cache = dirname(__DIR__).'/tmp';
      self::$loader = new \Twig\Loader\FilesystemLoader($templates);
      self::$twig = new \Twig\Environment(self::$loader, ['cahe'=>$cache]);

   }
   public static function SessionStart()
   {
     if (!isset($_SESSION)) 
     {
         session_start();
     } 
   }
   public static function view($url,$data)
   {
   	require_once $url;
   }
}
 ?>
