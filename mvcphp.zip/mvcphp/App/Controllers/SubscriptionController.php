<?php
require_once("Controller.php"); 
require_once("./Modeles/Database.php");
require_once("./Modeles/Shop.php");  
class SubscriptionController extends Controller
{
	public static function index($param=array())
	{
      $add ="";
      parent::SetTwig();
      parent::SessionStart();
      if(isset($_POST["statut"]))
      {
        if($_POST["statut"]=="pds")
        {
          $add = self::AddShop($_POST);
          echo parent::$twig->render('subscription.twig', ['name' => 'cheha','LogIn'=>'Identification']);
        }
        elseif($_POST["statut"]=="particulier")
        {}
      }
      elseif(isset($_POST["email"])&&$_POST['password'])
      {
        $log = self::ShopLogIn($_POST["email"],$_POST['password']);
        if($log=="Success")
          {
            //echo parent::$twig->render('home.twig', ['title' => 'home', 'MyCount'=>$_SESSION['MyOwnShop'],"LogIn"=>"Ma Boutique"]);
            header('Location: http://localhost/mvcphp/App/home/');
          }
        else{
          echo parent::$twig->render('subscription.twig', ['title' => 'subscription', 'result'=>$log." ; Veuillez vous inscrire","LogIn"=>"Identification"]);
           }
      }
      else
      {
        echo parent::$twig->render('subscription.twig', ['title' => 'LogIn',"LogIn"=>"Identification"]);
      }
		  //parent::view('subscription/index.php',["title"=>'Home',"value"=>"","ShopAdd"=>$add]);
	}


	public static function AddShop($form)
	{
      $shop = new Shop($form,false);
      $base = new Database();
		try
    	{
     	 	  $serShop = serialize($shop);
      		$email = $shop->getEmail();
      		$nom = $shop->getNom();
          $pays = $form["pays"];
          $type = $form["categorie"];
          if($form["pays"]=="Comores")
            {$ville = $form["ville"];}
          else
          {$ville = null;}
      		$motdepasse = password_hash($form["password"],PASSWORD_DEFAULT);
      		$exist = $base->Exist("pds","Email",$email);
      		if($exist) 
      	 	{
               $data = ["Motdepasse"=>$motdepasse,"Email"=>$email,"Objet"=>$serShop,"Nom"=>$nom,"Pays"=>$pays,"Ville"=>$ville,"Type"=>$type];
               $r = $base->InsertInto("pds",$data);              
               if($r=="1")
                 {
                    $shop->setUniqId($base);
                    $serShop = serialize($shop);
                    $res = $base->updateValue(array('Objet'=>$serShop,'Identifiant'=>$shop->uniqid),"pds",array('Email' => $email));
                    $shopDir = mkdir("../AppRessources/shops/".$shop->uniqid);
                    $imgDir = mkdir("../AppRessources/shops/".$shop->uniqid."/articles/");
                    $facDir = mkdir("../AppRessources/shops/".$shop->uniqid."/factures/");
                    $cliDir = mkdir("../AppRessources/shops/".$shop->uniqid."/clients/");
                    $auDir = mkdir("../AppRessources/shops/".$shop->uniqid."/autres/");
                    $dir = $shopDir && $imgDir && $facDir && $cliDir && $auDir;
                    if($res && $dir)        
                    {return "success";}
                    else{return "Error";}
                    $_POST = NULL;
                  }
               else{return "Error";}
            }
      	else
      	   {
               return "ShopExist";
     	      }      
      }
      catch(PDOException $error)
      {  
            return "Error";     
      }
	}

   private static function AddParticulier($form)
   {}



   /*Log functions*/

  private static function ShopLogIn($email,$motdepasse)
  { 
    if(empty($email) || empty($motdepasse))
      { 
          return "Vous devez fournir votre Email et votre mot de passe";
      }
        
    else{
          $dBname = 'djamnazi_marchands';
          $db = new Database($dBname);
          $found = $db->SearchIn(array('Motdepasse','Objet'),'pds',array('Email' => $email));
          if(empty($found))
          {
             return "Aucun compte trouvé avec cet Email";    
          }
          else
          {
            if(password_verify($motdepasse,$found[0]['Motdepasse']))
              {
                $_SESSION['MyOwnShop'] = unserialize($found[0]['Objet']);
                return "Success";                 
              } 
            else 
            {
              $found = NULL;
              $_POST = NULL;
            }
          }
        }
  }
}
?>