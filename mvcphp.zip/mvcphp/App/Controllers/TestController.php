<?php
require_once("Controller.php");
require_once("./Modeles/Database.php"); 
require_once("./Modeles/Categorie.php");    
class TestController extends Controller implements InterfaceController
{
	public static function index($parap=array())
	{
		$c = array(new Categorie("Alimentation",array()),new Categorie("Informatique",array()),new Categorie("Bricolage",array()),new Categorie("Decoration",array()),new Categorie("Vetements",array()));
		//var_dump($c);
		foreach ($c as $key => $value) {
			# code...
			$sc=serialize($value);
		    $value->saveCategorie($sc);
		}
		
		//$t = new Database("djamnazi_marchands");
		//$query = $t->updateValue(array("Nom"=>"cnom","Email"=>"cheikhmiradji@yahoo.fr"),"Pds",array("Email"=>"cheha1@hotmail.fr"));
		//parent::view('test/index.php',["title"=>'Home',"value"=>""]);
	}
}
?>