<?php
class Categorie 
{
   public $name = null;   
   public $parent ='parent cartegorie name';
   public $children = array();
   public $items =  array('items names' => 'ref item');
   public $filtres = array();
   public $Ref = NULL;
   public $stock = 0;
   public function __construct($name, $parent = "root")
   {
   	   $this->name = $name;
   	   $this->parent=$parent;
   	   if($parent!="root")
   	   {
   	   	 $p = self::getCategorie($parent);
   	   	 if($p!=null)
   	   	 {
   	   	 	$p->children[]=$this->name;
   	   	 	$pser = serialize($p);
   	   	 	$this->SerialObjectUpdate($pser,$p->name);
   	   	 }
   	   }
   }
   	public static function getCategorie($name)
	{

			$db = new Database('djamnazi_items');
			$cat = $db->SearchIn(array('SerialObject'),'categories',array('Name'=>$name));
			$result = array();
			foreach ($cat as $key => $value) {
				$result[] = unserialize($value[0]);
			}
			if(isset($result[0]))
				{return $result[0];}
			else{return null;}

	}

	public static function getCategories($parent)
	{
		$db = new Database('djamnazi_items');
		$cat = $db->SearchIn(array('SerialObject'),'categories',array('ParentName'=>$parent));
		$result = array();
		foreach ($cat as $key => $value) 
		{
			$result[] = unserialize($value[0]);
		}
		return $result;
	}
   public function addFiltre($name,$option=array())
   {
   	   if(!isset($this->$name))
   		{$this->filtres[$name] = $option;}
   }
   public function SetParent($parents=array())
   {
   		$this->parent=$parent;
   }
   public function getParent()
   {
   	  return $this->parent;
   }
   public function getChildren()
   {
   	  return $this->children;
   }
   public function saveCategorie($SerialCategorie)
   {
   	   $db = new Database('djamnazi_items');
   	   if($db->Exist('categories','Name',$this->name))
   	   {
   	   		$db->InsertInto('categories',array('Name'=>$this->name,'SerialObject'=>$SerialCategorie,'ParentName'=>$this->parent));
            $r = $db->SearchIn(array('Ref'),'categories',array('Name'=>$this->name));
            $this->Ref = $r[0]['Ref'];
            return 1;
   	   }
   	   else {return 0;} 
   }
   public function SerialObjectUpdate($so,$name)
   {
   	  $db = new Database('djamnazi_items');
   	  $db->updateValue(array('SerialObject'=>$so),'categories',array('Name'=>$name));
   }
   public function stockUpdate($stoc)
   {}
}
  ?>
