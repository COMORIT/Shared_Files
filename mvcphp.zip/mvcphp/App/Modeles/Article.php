<?php 
//include 'Database.php';
class Article{

	public $categorie;
	public $sousCategorie;
	public $nom;
	public $description;
	private $PointsDeLivraison;
	private $paiement;  //Mode de paiements (paypal ou autre)
	public $paiementEnPlusieursfois;
	private $reference;
	private $referenceFournisseur;
	//public $images = array();
	public $pathImage; 
	public $prix;
	private $disponibilite;
	private $avis = array();
	private $statistique;
	public $selection = array();
	public $marchand = '';
	public $marchandNom = '';
    
	public function __construct($form)
	{
   	$this->categorie = $form['Categorie'];
   	$this->nom = $form['Nom'];
   	$this->prix = $form['Prix'];
   	$this->disponibilite = $form['Disponibilite'];
   	$this->description = $form['Description'];
   	$this->sousCategorie = $form['SousCategorie'];
   	$this->referenceFournisseur = $form['FourRef'];
	}

	public function setReference($ref)
	{
		$this->reference = $ref;
	}

	public function setMarchand($m)
	{$this->marchand=$m;}
     
     public function getReference()
     { return $this->reference;}

     //retourne toutes les tables contenant la colonne $column
	
}

?>