<?php
class Admin
{
   public $nom;
   public $prenom;
   public $nomInfo='Aucun information supplémentaire';
   public $email;
   public $emailInfo='Aucun information supplémentaire';
   public $telephone;
   public $telephoneInfo='Aucun information supplémentaire';
   public $photo;
   public $datedenaissance;
   
   private $visible = FALSE; //afficher ou cacher la section admin
   
   public function __construct($form)
   {   
     $this->nom=$form['nomAdmin'];
 	  //$this->prenom=$form['prenomAdmin'];
 	  //$this->email=$form['email'];
    //$this->telephone = $form['telephoneAdmin'];
   }
   
   public function getChamps($champs)
   {
	    return $this->$champs;
   }
   
   public function setChamps($champs,$valeur,$adresseRetour)
   {
   	 if(isset($valeur))
   	 {
       $this->$champs=$valeur; 
       }
       else
       {
        //retour vers lien, aucune valeur soumise       
       }  
   }
   
   public function setPhoto($image,$adresseRetour)
   {
      if(isset($image))
      {
         //enregistrement un repertoir
         //$this->photo = chemin vers l'image      
      }
      else { //retour vers adresse retour, aucune image transmise                   
      }
   }
}
?>