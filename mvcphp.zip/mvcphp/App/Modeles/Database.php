<?php
//require 'dbpass.php';
class Database
{
    protected $pdo;
        
    public function __construct($dBname='djamnazi_marchands')
    {
        try
        {
           $this->pdo = new PDO('mysql:dbname='.$dBname.';host=localhost','root','');
           $this-> pdo -> setAttribute (PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);        
        }
        catch(PDOException $error)
        {   
        }
    }
    
    public function Exist($table,$colunm,$value)
	  {
   	    $res= $this->pdo->query("SELECT COUNT(*) FROM $table WHERE $colunm = '$value'");
   	    $res = (int)$res->fetchColumn();
        if($res == 0)
   	    {
     		   return true;   
   	    }
   	    else
   	    {
      	   return false;   
   	    }
	  }    
	  
/**********************************************************************************
                      Ajout, suppression dans DB
*********************************************************************************/
public function InsertInto($table,$columns) 
    {
    	try
    	{
          $r = "INSERT INTO "."`".$table."`(";
          $s = "VALUES (";  
          foreach($columns as $column => $value)
            {
              $r = $r."`".$column."`,";
              $s = $s."'".$value."',";
             // var_dump($value);
            }
            $r = rtrim($r,',');
            $s = rtrim($s,',');
            $r = $r.') ';
            $s = $s.')';
            //return $r.$s;
            $res = $this->pdo->exec($r.$s);
            return $res;                                           
      }
      catch(PDOException $error)
      {
       return "Error";       
      }
    }
    
public function deleteClient ($id,$table,$motdepasse)
  {
        try
    	  {     
        $eff = $this->pdo -> exec ("DELETE FROM `$table` WHERE `$table`.`Id` = '$id'");
        echo 'Vous avez ete bien supprime';                                     
        }
        catch(PDOException $errors)
        {  
            echo 'Vous n etes pas supprimer';
            var_dump($errors);      
        } 
        $this->pdo = NULL; 
      }
       
            
/********************************************************************************
                             Recherche dans DB
*****************************************************************************/    
    
 public function SearchIn($SelectColumns,$tables,$conditions)
     {    
          $sql = "SELECT ";
          foreach ($SelectColumns as $key => $value) {
            $sql = $sql.$value.", ";
          }
          $sql = rtrim($sql,' ');
          $sql = rtrim($sql,',');
          $sql = $sql." FROM ".$tables." WHERE ";
          if(empty($conditions))
          {
            $sql = $sql." 1";
          }
          foreach ($conditions as $key => $value) {
             $sql =  $sql.$key." "."= '".$value."'";
          }
          $res = $this->pdo->query($sql);
          $resultat = array();
            while($row=$res->fetch()) 
              {
                 $resultat[]=$row;           
              }
              $res->closeCursor();
        return $resultat;
  }


// Dictionnary = Key = Column and Value = Value
public function updateValue($Dictionnary,$table,$conditions)
{
  $sql = "UPDATE ".$table." SET";
  foreach ($Dictionnary as $key => $value) {
    $sql = $sql." ".$key."='".$value."',";
  }
  $sql = rtrim($sql,' ');
  $sql = rtrim($sql,',');
  $sql = $sql." WHERE ";
  foreach ($conditions as $key => $value) {
     $sql =  $sql.$key." "."= '".$value."'";
  }
  try{ 
    $res = $this->pdo->exec($sql);
    return $res;
  }
  catch(PDOException $error)
  {
    return "Can't update the value";
  }
}

}






    
?>