<?php

require_once 'Database.php';

class Client{
      protected $email;
      protected $nom;
      private $statut;
      
      private $adresse = 'Aucune adresse';
      private $pays;
      
      private $telephone=array();
      
      private $localisation;  
      public $adresseMAC;      
          
      public function __construct($form,$log)
      {
      	if($log) {
      	  $this->email=$form['email'];
         }
         else 
         {
           $this->email=$form['email'];
           $this->nom=$form['nom'];
           $this->statut=$form['statut'];           
           $this->telephone[]=$form['telephone'];
           $this->pays = $form['pays'];     
   		     if($form['pays']=='France') 
   				   {
   				       $voiefrance = explode(',',$form['rue']);
           			 $voiefrance[] = ' ';
           			 $adressefrance = $voiefrance[0].' '.$form['codepostale'].' '.$voiefrance[1].' (France)';
         			   $this->adresse = $adressefrance;   	
      			 }
    				else 
             { 
    					   $adressecomores= explode(',',$form['ville'])[0].' '.explode(',',$form['region_co'])[0].'';
    					   $this->adresse=$adressecomores;
    					}
         }
      }
  
public function setAdresse($form,$lienRetour=NULL)
{
	if(isset($form['pays']) && (isset($form['ville']) || isset($form['rue']))) 
	{
	$this->pays=$form['pays'];
     
   if($form['pays']=='France') 
   	{
  		 	$voiefrance = explode(',',$form['rue']);
   		$voiefrance[] = ' ';
   		$adressefrance = $voiefrance[0].' '.$form['codepostale'].' '.$voiefrance[1].' (France)';
         $this->adresse = $adressefrance;
       }   	
  else { 
    		$adressecomores= explode(',',$form['ville'])[0].' '.explode(',',$form['region_co'])[0].' (Comores)';    
    		$this->adresse=$adressecomores;
    	 }
    }   
    else { //retour probleme adresse
         } 
}

public function updateAdresse($adresse)
{$this->adresse = $adresse;}

public function getAdresse()
{
  return $this->adresse;
}    
     
public function getNom() 
{ return $this->nom;}

public function setNom($nom)
{$this->nom = $nom;}

public function setEmail($email)
{$this->email = $email;}

public function getEmail() 
{ 		return $this->email;}

public function setTelephone($form,$adresseRetour=NULL)
{
	if(filter_var($form, FILTER_VALIDATE_INT)) { $this->telephone[0]=$form; }
	else { //retour problème telephone }
		  }
}

public function getTelephone()
{
	return $this->telephone;
}

public function getStatut() {return $this->statut;}

private function verifierMotDePasse($motdepasse,$confmotdepasse) 
{
     if(isset($motdepasse) && isset($confmotdepasse))
     {
        if($motdepasse==$confmotdepasse) 
        {
          return true;        
        } 
        else 
        {
        	return false;
        }
     }
     else{ 
          
     return false;}
  }
  
  
      
public function statistique()
 {
         //renveoie un tableau qu contient le nombre d'abonné, le nombre de connexion, la fréquence de connexion, un tableau des derniers 
         //actions, montant globale des transaction, moyenne par transaction ..  ( creer une classe action)
 }

}

?>