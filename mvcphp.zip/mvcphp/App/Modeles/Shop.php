<?php
require_once 'Database.php';
require_once 'Client.php';
require 'Admin.php';
class Shop extends Client{
   
   private $categorie;
   private $scategorie;
   private $admin;
   private $dB;

   private $InfoSup = array('nom'=>'Aucune information supplémentaire',
   'telephone'=>'Aucune information supplémentaire',
   'adresses'=>'Aucune information supplémentaire', 'horaires'=>'Aucune information supplémentaire',
   'siteinternet'=>'Aucune information supplémentaire');
   
   private $couverture;   //photo de couvertures
   private $siteinternet= array('siteoff'=>array('Aucun site internet ajouté'),'réseaux'=>array('Aucun réseau social ajouté'));
   private $reseaux=array('Aucun site internet ajouté');
   								
   private $ServProd = array();  //tableau d'objets de type Produit
   private $ListProd = array(); //liste de listes de produits  
    										                                    
   private $post = array();         //tableau d'objets contienant une image, un texte, et une video
   private $abonnee = array();      // Tableau contenant les references des abonnées

   private $avis = array();
   private $sections = array(); //tableau d'Objects de type section
   public $presentation = 'Aucune présentation ajoutée';

   public $horaires = array('Lundi'=>array('00h','00h'),'Mardi'=>array('00h','00h'),'Mercredi'=>array('00h','00h'),'Jeudi'=>array('00h','00h'),'Vendredi'=>array('00h','00h'),'Samedi'=>array('00h','00h'),'Dimanche'=>array('00h','00h'));
   public $uniqid = NULL;
   
   public function __construct($form,$connex)
   {  
     parent::__construct($form,$connex);
          
     $this->categorie=$form['categorie'];
     $this->scategorie=$form['scategorie'];
     $this->admin=new Admin($form); 
         
    }
    
    public function set_data($data,$valeur)
    {
       $this->$data=$valeur;

    }
    
    public function setAdmin($form) 
    {
       $this->admin=new Admin($form);  
    }
    
    public function getAdmin()
 	   { return $this->admin;}
 	 
 	 public function getCategorie()
 	 {return $this->categorie;}
 	 
 	 public function setCategorie($cat)
 	 {$this->categorie=$cat;}
 	 
 	 public function getSiteInternet($site)
 	 {return $this->siteinternet[$site];}
 	 
 	 public function setInfo($info,$valeur)
 	 { if(isset($valeur)) {
 	   $this->InfoSup = $valeur;}
 	    else {
            //retour aucune valeur soumise 	    
 	    }  
 	 }
 	 
 	 public function getInfo($info)
 	 {return $this->InfoSup[$info];}
 	 

 	 public function getUniqId()
 	 {
 	 	//Aller le checher dans le DB t le retourner
    return $this->uniqid;
 	 }    
   public function setUniqId($db)
   {
       $strId=$db->SearchIn(array('Uniqid'),'pds',array('Email' => $this->email));
       $this->uniqid = strtoupper(substr($this->nom,0,3).dechex(rand(0,255)).dechex(intval($strId[0]['Uniqid'])));
       //$this->uniqid = dechex(intval($IncId[0]));
   }

}
?>