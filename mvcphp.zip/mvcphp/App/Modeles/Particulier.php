<?php

require 'Client.php';

class Particulier extends Client
{   	
	private $prenom;
	private $sexe = 'Ajouter';	      	
	private $adressedelivraison = '';	
	private $factures = array(); //tableaux d'objets factures  
  private $panier = '';    //il faudra creer une classe panier contenant les articles et l'adresse de livraison 
  private $autre = 'ajouter une description ou tout autre élement important';
  private $documents = array('');
  private $profession = '';
  private $datedenaissance;
  private $qui_charges = array(); //en index le nom de la personne pointant vers un tableau contenant ceux dont il a droit
      
  public function __construct($form,$connex=FALSE)
  {  
     parent::__construct($form,$connex);
     $this->prenom=$form['prenom'];
  }
    
   public function setPrenom($valeur,$adresseRetour=NULL)
   {
   	if(isset($valeur['prenom']))
   	{
   	$this->prenom=$valeur['prenom'];
      }
      else{
      //retour probleme prenom
      }   
   }
   
   public function getPrenom() 
   {
   return $this->prenom;   
   }
   
   public function setDateDeNaissance($date,$adresseRetour=NULL)
   {
      if ((preg_match('~^(\d{1,2})([ /-])(\d{1,2})\2([1-2]\d{3})$~D', $date, $matches)==1) && checkdate($matches[3], $matches[1], $matches[4])) 
  			{
  			$an = (int) $matches[4];
  			if(($an < 1960) || ($an > 2010) ) 
  			{
  			//	date de naissance hors tranche
  			}
  			else {$this->datedenaissance=$date;}
  			}
  			else {//retour mauvaise date de naissance}
   }
	}
   
   public function getDateDeNaissance()
   {
         return $this->datedenaissance;   
   }
   
   public function setLieuDeNaissance($form,$adresseRetour=NULL)
   {
      if (isset($form['lieudenaissance'])) 
  			{
			$this->lieudenaissance=$form['lieudenaissance'];
			}
  			else {//retour mauvaise date de naissance
  			}
   }
   
   public function getLieuDeNaissance()
   {
         return $this->lieudenaissance;   
   }   
   
   public function setSexe($form)
   {
      return $this->sexe = $form['sexe'];
   }
   
   public function getSexe()
   {
      return $this->sexe;   
   }
   
   public function setAutre($form,$lienDeRetour=NULL)
   {
   	if(isset($form['autre'])) {
      $this->sexe = $form['autre'];
      }
      else { //retour rien n'est envoyé
  			  }
   }
   
   public function getAutre()
   {
      return $this->autre;   
   }
   
   public function getProfession()
   {
      return $this->profession;   
   }
   
   public function setAdresseDeLivraison($pdl=NULL,$adressefrance=NULL) 
   {
   	if(isset($pdl))
   	{
		$this->adressedelivraison = $pdl;   	
   	}
   	elseif(isset($adressefrance)) { $this->adressedelivraison=$adressefrance; }
   }
   
   public function getAdresseDeLivraison()
   {
		return $this->adressedelivraison;   
   }
    
}
?>