<?php

///require 'Database.php';
class ItemsDataBase extends Database
{
  public function __construct()
  {  
     parent::__construct('djamnazi_articles');
  }

  public function getItems($tables,$conditions,$all=true)
  {
  	if($all)
  	{
  	
  		$tables_names = $this->getTablesNames();
  	}
  	else
  	{
  		$tables_names = array();
  	}
  	return $tables_names;

  }

  private function getTablesNames()
  {
  		$res = $this->pdo->query("SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE'");
  	    //$res = $this->pdo->query($sql);
        $resultat = array();
        while($row=$res->fetch()) 
            {
            	if($row[1]=="djamnazi_articles")
                 {$resultat[]=$row[2];}           
            }
            //var_dump($resultat);
        $res->closeCursor();
        return $resultat;
  }

}


  ?>