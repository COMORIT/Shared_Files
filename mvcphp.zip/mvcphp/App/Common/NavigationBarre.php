
        <div id="mainBar" style="">
            <ul id="ul-mainBar" >
                <from>
                    <select id="select-mainBar">
                        <option>Tout</option>
                        <option>Multimedia</option>
                        <option>Construction</option>
                     </select>
                     <input type="search" style="" id="input-search" name="" placeholder="Recherche">
                     <button type="submit" id="submit-search"><i class="fa fa-search"></i></button>
                </from>
                <li id="Home" onclick="window.location.href='../home'">Accueil</li>
                <li id="catalog">Calalogues</li>
                <li id="Help">Aide<em style="border: 1px solid white;border-radius: 15px;padding: 1px 6px 1px 6px;margin-left: 5px;color: white;"><b>?</b></em></li>
                <li id="Subscription"  onmouseover="EnableDarkScreen()" onmouseout="DesableDarkScreen()">Identification
                    <ul style="">
                        <div id="form-logIn">
                             <fieldset id="logIn-field">
                                <legend id="triangle"></legend>
                                    <form style="margin-bottom: 15px;text-align:center;" action="../subscription/" method="post">
                                        <label for="email" class="label-logIn">Email :</label>
                                        <input type="text" id="logEmail" name="email" placeholder="cheikhmiradji@yahoo.fr" class="input-logIn-field" style=""><br>
                                        <label for="password" class="label-logIn">Mot de passe:</label>
                                        <input type="password" id="logPassword" class="input-logIn-field" name="password" placeholder="************" ><br/><input type="submit" class="submit-logIn" value="Connexion">
                                        <input type="button" class="submit-logIn" value="Nouveau Compte" onclick="window.location='../subscription'">
                                    </form>
                            </fieldset>
                        </div>    
                    </ul>
                </li>
                <li id="for" onclick="window.location.href=''" style="padding-right: 0px;">Panier
                       <div style=" float:right; position: relative;right:10px;top: -2px;margin-left: 20px;">
                             <img src="../../AppRessources/icones/panier.png" style="border: 1px solid white;border-radius: 20px;width: 17px;height: 18px;padding: 2px;">
                            <small style="background-color: red;border-radius: 2px;padding: 3px 6px 0.5px 6px;margin-left: -3px;">1000<sup>FC</sup>
                            </small>
                        </div>
                </li>
            </ul>
        </div>
