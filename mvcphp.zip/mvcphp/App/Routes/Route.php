<?php
Class Route
{
	public static function create($route,$url_base,$routeHander)
	{
        if($route==$url_base)
        	{ $routeHander->__invoke();}
	}

}
 ?>