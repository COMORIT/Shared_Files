<?php
   $taburl = str_replace('[\]','/',$_GET['url']);
   $_GET = null;
   $taburl = preg_split('[/]',$taburl);
   $_POST['httpArgs']=$taburl;
   require_once('Route.php');

   $validRoutes = array('home','subscription','shop','help','item');
   /* 
    Home route
   */
    require_once('Controllers/HomeController.php');
   Route::create('home',$taburl[0],function(){HomeController::index($_POST['httpArgs']);});

    /* 
    Subscription route
   */
    require_once('Controllers/SubscriptionController.php');
   Route::create('subscription',$taburl[0],function(){SubscriptionController::index($_POST['httpArgs']);});

    /*
    Shop route
   */
    require_once('Controllers/BazarController.php');
   Route::create('bazar',$taburl[0],function(){BazarController::index($_POST['httpArgs']);});

       /*
    Log In and out route
   */
    require_once('Controllers/LogController.php');
   Route::create('log',$taburl[0],function(){LogController::index($_POST['httpArgs']);});

    
    require_once('Controllers/MyitemsController.php');
   Route::create('myitems',$taburl[0],function(){MyitemsController::index($_POST['httpArgs']);});

       /* 
    Test route
   */
    require_once('Controllers/TestController.php');
   Route::create('test',$taburl[0],function(){TestController::index($_POST['httpArgs']);});

  unset($_POST['httpArgs']);
 ?>